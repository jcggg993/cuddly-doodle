-- Supabase starter schema (not yet wired to the HTML prototype)
-- Run in Supabase SQL Editor only after creating a project and reviewing the policies.

create table if not exists public.products (
  id text primary key,
  name text not null,
  price_minor integer not null check (price_minor >= 0),
  active boolean not null default true
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id),
  provider text not null,
  provider_order_id text unique,
  status text not null default 'pending'
    check (status in ('pending','paid','refunded','cancelled')),
  amount_minor integer not null check (amount_minor >= 0),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);

create table if not exists public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null references public.products(id),
  order_id uuid references public.orders(id),
  status text not null default 'active'
    check (status in ('active','revoked','expired')),
  created_at timestamptz not null default now(),
  expires_at timestamptz,
  unique(user_id, product_id)
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.entitlements enable row level security;

-- Users can read their own orders and entitlements only.
create policy "read own orders" on public.orders
for select to authenticated using (auth.uid() = user_id);

create policy "read own entitlements" on public.entitlements
for select to authenticated using (auth.uid() = user_id);

-- Intentionally no client insert/update policies for orders or entitlements.
-- A trusted server / Edge Function must create orders, validate provider callbacks,
-- mark paid orders, and grant/revoke entitlements. Never trust a browser redirect
-- as proof of payment. Keep service-role keys server-side only.

insert into public.products(id,name,price_minor,active)
values ('love-notes-full-report','心动说明书完整报告',1290,true)
on conflict (id) do nothing;
